package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Banji;

import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;


import java.util.List;


public class BanjiMapperTest {

    @Test
    public void insert() {

    SqlSession sqlSession= MyBatisUtil.getSqlSession();
    BanjiMapper mapper = sqlSession.getMapper(BanjiMapper.class);
    Banji banji=new Banji();

    banji.setCno("05");
    banji.setCnum("90");
    banji.setCpeo("刘继华");
    banji.setCtel("13478900987");
    banji.setFpeo("张美兰");
    banji.setFtel("16545678765");
    banji.setSdate("2021");
    banji.setEdate("2025");
   banji.setBeizhu("05");
    int res1=mapper.insert(banji);
        if(res1>0)
    {
        sqlSession.commit();
        System.out.println("添加成功");
    }
        else{
        sqlSession.rollback();
        System.out.println("添加失败");
    }
        MyBatisUtil.close(sqlSession);
    }
    @Test
    public void selectAll4() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        BanjiMapper mapper = sqlSession.getMapper(BanjiMapper.class);
        List<Banji> bans = mapper.selectAll4();
        System.out.println(bans);
        sqlSession.close();
        MyBatisUtil.close(sqlSession);

    }
    @Test
    public void selectById() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        BanjiMapper mapper = sqlSession.getMapper(BanjiMapper.class);
        Banji banji = mapper.selectById(11);
        System.out.println(banji);
        MyBatisUtil.close(sqlSession);
    }
}