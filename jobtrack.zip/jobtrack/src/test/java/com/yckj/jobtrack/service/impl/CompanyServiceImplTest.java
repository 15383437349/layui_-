package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.service.ICompanyService;
import org.junit.Test;

import java.util.List;

public class CompanyServiceImplTest {
     private ICompanyService companyService=new CompanyServiceImpl();
    @Test
    public void addCompany() {
        Company company=new Company();
        company.setCname("北京京杭");
        company.setAddress("北京西城区");
        company.setLeader("李先生");
        company.setTelephone("13456788765");
        company.setStatus(1);
        boolean flag=companyService.addCompany(company);
        if(flag){
            System.out.println("添加成功");
        }
        else{
            System.out.println("添加失败");
        }

    }

    @Test
    public void findAll() {

        List<Company> companies = companyService.findAll();
        System.out.println(companies);
    }

    public void  findCompanyById(){
        Company company = companyService.findCompanyById(6);
        System.out.println(company);
    }
}