package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.domain.Student;
import com.yckj.jobtrack.service.ICompanyService;
import com.yckj.jobtrack.service.IStudentService;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class StudentServiceImplTest {
    private IStudentService studentService=new StudentServiceImpl();
    @Test
    public void addStudent() {
        Student student=new Student();
        student.setBan("09班");
        student.setDate1("2020");
        student.setSex(0);
        student.setSname("李华");
        student.setTelno("14433554466");
      student.setWno("13344556677");
        boolean flag=studentService.addStudent(student);
        if(flag){
            System.out.println("添加成功");
        }
        else{
            System.out.println("添加失败");
        }
    }

    @Test
    public void findAll5() {
        List<Student> students = studentService.findAll5();
        System.out.println(students);
    }

    @Test
    public void findStudentById() {
        Student student = studentService.findStudentById(6);
        System.out.println(student);
    }


}