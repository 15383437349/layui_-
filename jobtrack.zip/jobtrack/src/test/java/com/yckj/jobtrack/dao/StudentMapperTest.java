package com.yckj.jobtrack.dao;


import com.yckj.jobtrack.domain.Student;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class StudentMapperTest {

    @Test
    public void insert() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        Student student=new Student();
        student.setBan("4班");
        student.setQno("1564545345");
        student.setSno("1004");
        student.setSname("兰兰");
        student.setTelno("13454322345");
        student.setWno("14356564567");
        int res=mapper.insert(student);
        if(res>0)
        {
            sqlSession.commit();
            System.out.println("添加成功");
        }
        else{
            sqlSession.rollback();
            System.out.println("添加失败");
        }
        MyBatisUtil.close(sqlSession);
    }

    @Test
    public void selectAll5() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        List<Student> students = mapper.selectAll5();
        System.out.println(students);
        sqlSession.close();
        MyBatisUtil.close(sqlSession);
    }

    @Test
    public void selectById() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        Student student = mapper.selectById(11);
        System.out.println(student);
        MyBatisUtil.close(sqlSession);
    }


}