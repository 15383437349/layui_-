package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.domain.User;
import com.yckj.jobtrack.service.IUserService;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserServiceImplTest {

    @Test
    public void login() {
        IUserService userService=new UserServiceImpl();
        User user=new User();
        user.setUsername("jun");
        user.setPassword("123456");
        boolean login = userService.login(user);
        if(login){
            System.out.println("登陆成功");
        }else {
            System.out.println("登录失败");
        }
    }
}