package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class CompanyMapperTest {

    @Test
    public void insert() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        CompanyMapper mapper = sqlSession.getMapper(CompanyMapper.class);
        Company company=new Company();
        company.setCname("北京蓝天");
        company.setAddress("北京昌平区");
        company.setLeader("王先生");
        company.setTelephone("13456788765");
        company.setStatus(1);
        int res=mapper.insert(company);
        if(res>0)
        {
            sqlSession.commit();
            System.out.println("添加成功");
        }
        else{
            sqlSession.rollback();
            System.out.println("添加失败");
        }
        MyBatisUtil.close(sqlSession);
    }

    @Test
    public void selectAll() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        CompanyMapper mapper = sqlSession.getMapper(CompanyMapper.class);
        List<Company> companies = mapper.selectAll();
        System.out.println(companies);
        sqlSession.close();
        MyBatisUtil.close(sqlSession);



    }
    @Test
    public void selectById(){
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        CompanyMapper mapper = sqlSession.getMapper(CompanyMapper.class);
        Company company = mapper.selectById(6);
        System.out.println(company);
        MyBatisUtil.close(sqlSession);
    }


}