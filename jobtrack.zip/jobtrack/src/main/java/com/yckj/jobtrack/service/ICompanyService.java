package com.yckj.jobtrack.service;

import com.yckj.jobtrack.domain.Company;

import java.util.List;

public interface ICompanyService {
    /*
    * 添加合作企业，值为false表示添加失败
    * */
    boolean addCompany(Company company);
    List<Company> findAll();


    Company findCompanyById(int id);

    boolean editCompany(Company company);



    boolean removeById(int id);
}
