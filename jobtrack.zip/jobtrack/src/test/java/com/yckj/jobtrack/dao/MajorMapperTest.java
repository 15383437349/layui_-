package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Major;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class MajorMapperTest {



    @Test
    public void insert() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        MajorMapper mapper = sqlSession.getMapper(MajorMapper.class);
        Major major=new Major();
        major.setMname("计算机工程");
        major.setCdate("2017");
        major.setBeizhu("无 ");
        int res1=mapper.insert(major);
        if(res1>0)
        {
            sqlSession.commit();
            System.out.println("添加成功");
        }
        else{
            sqlSession.rollback();
            System.out.println("添加失败");
        }
        MyBatisUtil.close(sqlSession);
    }
    @Test
    public void selectAll3() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        MajorMapper mapper = sqlSession.getMapper(MajorMapper.class);
        List<Major> majors=mapper.selectAll3();
        System.out.println(majors);
        sqlSession.close();
        MyBatisUtil.close(sqlSession);

    }
}