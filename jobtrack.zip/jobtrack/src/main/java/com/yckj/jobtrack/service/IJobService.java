package com.yckj.jobtrack.service;

import com.yckj.jobtrack.domain.Job;

import java.util.List;

public interface IJobService {
    /*
     * 添加招聘工作信息，值为false表示添加失败
     * */
    boolean addJob(Job job);
    List<Job> findAll2();
    Job findJobById(int id);
}
