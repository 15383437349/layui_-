package com.yckj.jobtrack.servlet;

import com.yckj.jobtrack.domain.User;
import com.yckj.jobtrack.service.IUserService;
import com.yckj.jobtrack.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       //设置编码
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        // 获取用户名
        String username = req.getParameter("username");
        // 获取密码
        String password = req.getParameter("password");
        // 获取输入的验证
        String code = req.getParameter("code");

        // 获取生成的验证码
        String sessionCode = (String)req.getSession().getAttribute("code");

        PrintWriter writer = resp.getWriter();
        // 验证验证码
        if(code == null || "".equals(code) || !code.equalsIgnoreCase(sessionCode)){
            writer.print(0);
            return;
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        IUserService userService = new UserServiceImpl();
        boolean login = userService.login(user);
        if(login){
            writer.print(1);
        }else{
            writer.print(2);
        }

        writer.close();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       // super.doPost(req, resp);
        doGet(req,resp);
    }
}
