package com.yckj.jobtrack.dao;


import com.yckj.jobtrack.domain.Job;

import java.util.List;

public interface JobMapper {
    /*插入添加企业的信息*/
    int insert(Job job);
    /*查询添加企业的信息*/
    List<Job> selectAll2();

    Job selectById2(int id);


}
