package com.yckj.jobtrack.service.impl;



import com.yckj.jobtrack.dao.MajorMapper;

import com.yckj.jobtrack.domain.Major;
import com.yckj.jobtrack.service.IMajorService;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class MajorServiceImpl  implements IMajorService {

    @Override
    public boolean addMajor(Major major) {
        boolean flag = false;
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        MajorMapper mapper = sqlSession.getMapper(MajorMapper.class);
        int res = mapper.insert(major);
        if (res > 0) {
            sqlSession.commit();
            flag = true;
        } else {
            sqlSession.rollback();
        }
        return flag;

    }

    public List<Major> findAll3() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        MajorMapper mapper = sqlSession.getMapper(MajorMapper.class);
        List<Major> majors = mapper.selectAll3();
        return majors;
    }
}
