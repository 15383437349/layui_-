package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.service.ICompanyService;
import com.yckj.jobtrack.util.MyBatisUtil;
import com.yckj.jobtrack.dao.CompanyMapper;
import com.yckj.jobtrack.domain.Company;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class CompanyServiceImpl implements ICompanyService {

/*
* 添加企业
* */
    @Override
    public boolean addCompany(Company company) {
        boolean flag=false;
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        CompanyMapper mapper = sqlSession.getMapper(CompanyMapper.class);
        int res = mapper.insert(company);
        if(res > 0)
        {
            sqlSession.commit();
            flag=true;
        }
        else{
            sqlSession.rollback();
        }
        return flag;
    }
/*
* 查询企业
* */
    @Override
    public List<Company> findAll() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        CompanyMapper mapper = sqlSession.getMapper(CompanyMapper.class);
        List<Company> companies = mapper.selectAll();
        return companies;
    }

    @Override
    public Company findCompanyById(int id) {
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        CompanyMapper mapper=sqlSession.getMapper(CompanyMapper.class);
        Company company = mapper.selectById(id);
        return company;
    }
/*
* 修改企业
* */
    @Override
    public boolean editCompany(Company company) {
        boolean flag =false;
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        CompanyMapper mapper=sqlSession.getMapper(CompanyMapper.class);
        int res =mapper.update(company);
        if(res > 0){
            sqlSession.commit();
            flag=true;
        }
        else{
            sqlSession.rollback();
        }
        return flag;
    }


/*
* 删除合作企业
* */

    @Override
    public boolean removeById(int id) {
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        CompanyMapper mapper=sqlSession.getMapper(CompanyMapper.class);


        int res=mapper.deleteById(id);
        if(res > 0){
            sqlSession.commit();
            return true;
        }
        else{
            sqlSession.rollback();
            return false;
        }

    }
}
