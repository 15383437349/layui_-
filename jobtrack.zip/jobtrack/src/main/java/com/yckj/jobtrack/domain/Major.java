package com.yckj.jobtrack.domain;

public class Major {
    private Integer  id;
    private  String mname;
    private  String  cdate;
    private  String  beizhu;

    @Override
    public String toString() {
        return "Major{" +
                "id=" + id +
                ", mname='" + mname + '\'' +
                ", cdate='" + cdate + '\'' +
                ", beizhu='" + beizhu + '\'' +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    public String getCdate() {
        return cdate;
    }

    public void setCdate(String cdate) {
        this.cdate = cdate;
    }

    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu;
    }
}

