package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.dao.BanjiMapper;
import com.yckj.jobtrack.domain.Banji;
import com.yckj.jobtrack.service.IBanjiService;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class BanjiServiceImpl  implements IBanjiService {
    public boolean addBanji(Banji banji) {
        boolean flag = false;
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        BanjiMapper mapper = sqlSession.getMapper(BanjiMapper.class);
        int res = mapper.insert(banji);
        if (res > 0) {
            sqlSession.commit();
            flag = true;
        } else {
            sqlSession.rollback();
        }
        return flag;

    }

    public List<Banji> findAll4() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        BanjiMapper mapper = sqlSession.getMapper(BanjiMapper.class);
        List<Banji> banjis = mapper.selectAll4();
        return banjis;
    }
    @Override
    public Banji findBanjiById(int id) {
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        BanjiMapper mapper=sqlSession.getMapper(BanjiMapper.class);
        Banji banji = mapper.selectById(id);
        return banji;
    }
    /*
     * 修改企业
     * */
    @Override
    public boolean editBanji(Banji banji) {
        boolean flag =false;
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        BanjiMapper mapper=sqlSession.getMapper(BanjiMapper.class);
        int res = mapper.update(banji);
        if(res > 0){
            sqlSession.commit();
            flag=true;
        }
        else{
            sqlSession.rollback();
        }
        return flag;
    }


    /*
     * 删除合作企业
     * */

    @Override
    public boolean removeById(int id) {
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        BanjiMapper mapper=sqlSession.getMapper(BanjiMapper.class);


        int res=mapper.deleteById(id);
        if(res > 0){
            sqlSession.commit();
            return true;
        }
        else{
            sqlSession.rollback();
            return false;
        }

    }

}
