package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.dao.CompanyMapper;
import com.yckj.jobtrack.dao.StudentMapper;
import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.domain.Student;
import com.yckj.jobtrack.service.IStudentService;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class StudentServiceImpl implements IStudentService {
    /*
     * 添加企业
     * */
    @Override
    public boolean addStudent(Student student) {
        boolean flag=false;
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        int res = mapper.insert(student);
        if(res > 0)
        {
            sqlSession.commit();
            flag=true;
        }
        else{
            sqlSession.rollback();
        }
        return flag;
    }
    /*
     * 查询企业
     * */
    @Override
    public List<Student> findAll5() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        StudentMapper mapper = sqlSession.getMapper(StudentMapper.class);
        List<Student> students = mapper.selectAll5();
        return students;
    }

    @Override
    public Student findStudentById(int id) {
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        StudentMapper mapper=sqlSession.getMapper(StudentMapper.class);
        Student student = mapper.selectById(id);
        return student;
    }
    /*
     * 修改企业
     * */
    @Override
    public boolean editStudent(Student student) {
        boolean flag =false;
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        StudentMapper mapper=sqlSession.getMapper(StudentMapper.class);
        int res =mapper.update(student);
        if(res > 0){
            sqlSession.commit();
            flag=true;
        }
        else{
            sqlSession.rollback();
        }
        return flag;
    }


    /*
     * 删除合作企业
     * */

    @Override
    public boolean removeById(int id) {
        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        StudentMapper mapper=sqlSession.getMapper(StudentMapper.class);


        int res=mapper.deleteById(id);
        if(res > 0){
            sqlSession.commit();
            return true;
        }
        else{
            sqlSession.rollback();
            return false;
        }

    }
}
