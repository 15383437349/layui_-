package com.yckj.jobtrack.servlet;

import com.google.gson.Gson;
import com.yckj.jobtrack.domain.Banji;

import com.yckj.jobtrack.service.IBanjiService;
import com.yckj.jobtrack.service.impl.BanjiServiceImpl;
import org.apache.log4j.Logger;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(value="/BanjiServlet")
public class BanjiServlet extends HttpServlet {
    private Logger logger=Logger.getLogger(this.getClass());
    private IBanjiService banjiService=new BanjiServiceImpl();
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        //设置编码
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String method = req.getParameter("method");
        if("findAll4".equals(method)){
            this.findAll4(req,resp);

        }else if("addBanji".equals(method)) {
            this.addBanji(req, resp);
        }
        else if("findBanjiById".equals(method)){
            this.findBanjiById(req,resp);
        }else if("editBanji".equals(method)){
            this.editBanji(req,resp);
        }else if("removeById".equals(method)) {
            this.removeById(req, resp);
        }else{
            logger.debug("没有这个请求地址");
        }
    }

    private void addBanji(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        String data = req.getParameter("data");
        logger.debug("data:"+data);
        Gson gson=new Gson();
        Banji banji= gson.fromJson(data, Banji.class);

        logger.debug("banji:"+banji);
        boolean flag2=banjiService.addBanji(banji);
        PrintWriter writer=resp.getWriter();
        if(flag2){
            writer.print(1);
        }else {
            writer.print(0);
        }
    }

    private void findAll4(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        List<Banji> banji = banjiService.findAll4();
        Map<String,Object> map= new LinkedHashMap<String,Object>();
        map.put("code",0);
        map.put("msg","");
        map.put("count",100);
        map.put("data",banji);
        Gson gson=new Gson();
        String json = gson.toJson(map);
        logger.debug(json);
        PrintWriter writer = resp.getWriter();
        writer.print(json);
        writer.close();
    }
    private void findBanjiById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        logger.debug("id="+id);

        if (id != null) {
            int i = Integer.parseInt(id);
            Banji banji = banjiService.findBanjiById(i);
            req.getSession().setAttribute("banji",banji);
            req.getRequestDispatcher(req.getContextPath()+"/page/class/editclass.jsp").forward(req,resp);
        }else{
            logger.debug("id为空");
        }

    }
    /*修改*/
    private void editBanji(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String data = req.getParameter("data");

        Gson gson=new Gson();
        Banji banji = gson.fromJson(data,Banji.class);

        boolean flag = banjiService.editBanji(banji);
        PrintWriter writer=resp.getWriter();
        if(flag){
            writer.print(1);
        }else {
            writer.print(0);
        }
        writer.close();
    }
    /*删除*/
    private void removeById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");


        if (id != null) {
            int i = Integer.parseInt(id);

            boolean flag= banjiService.removeById(i);

            PrintWriter writer = resp.getWriter();
            if(flag){
                writer.print(1);
            }else{
                writer.print(0);
            }
        }else{
            logger.debug("id为空");
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
