package com.yckj.jobtrack.service;

import com.yckj.jobtrack.domain.User;

public interface IUserService {
    boolean login(User user);
}
