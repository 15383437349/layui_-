package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.domain.Banji;

import com.yckj.jobtrack.service.IBanjiService;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class BanjiServiceImplTest {
   private  IBanjiService BanjiService=new BanjiServiceImpl();
    @Test
    public void addBanji() {
        Banji banji =new Banji();
        banji.setCno("08班");
        banji.setSdate("2017");
        banji.setEdate("2021");
        banji.setCpeo("刘敏");
        banji.setCtel("13456765456");
        banji.setFpeo("李兰");
        banji.setFtel("13454345455");
        banji.setBeizhu("08班");
        boolean flag= BanjiService.addBanji(banji);
        if(flag){
            System.out.println("添加成功");
        }
        else{
            System.out.println("添加失败");
        }
    }

    @Test
    public void findAll4() {
        List<Banji> banji= BanjiService.findAll4();
        System.out.println(banji);
    }

    @Test
    public void findBanjiById() {
        Banji banji = BanjiService.findBanjiById(10);
        System.out.println(banji);
    }
}