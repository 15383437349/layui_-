package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.User;
import org.apache.ibatis.annotations.Param;

public interface UserMapper {
     User selectByUsernameAndPwd(@Param("username") String username,@Param("password")  String password) ;


}