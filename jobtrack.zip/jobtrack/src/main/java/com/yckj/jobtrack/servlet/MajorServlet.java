package com.yckj.jobtrack.servlet;

import com.google.gson.Gson;


import com.yckj.jobtrack.domain.Major;
import com.yckj.jobtrack.service.IMajorService;
import com.yckj.jobtrack.service.impl.MajorServiceImpl;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(value="/MajorServlet")
public class MajorServlet extends HttpServlet {
    private Logger logger=Logger.getLogger(this.getClass());
    private IMajorService majorService=new MajorServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置编码
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String method = req.getParameter("method");
        if("findAll3".equals(method)){
            this.findAll3(req,resp);

        }else if("addMajor".equals(method)) {
            this.addMajor(req, resp);
        }else{
            logger.debug("没有这个请求地址");
        }
    }



    private void findAll3(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        List<Major> majors = majorService.findAll3();
        Map<String,Object> map= new LinkedHashMap<String,Object>();
        map.put("code",0);
        map.put("msg","");
        map.put("count",100);
        map.put("data",majors);
        Gson gson=new Gson();
        String json = gson.toJson(map);
        logger.debug(json);
        PrintWriter writer = resp.getWriter();
        writer.print(json);
        writer.close();

    }

    private void addMajor(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        String data = req.getParameter("data");
        logger.debug("data:"+data);
        Gson gson=new Gson();
        Major major = gson.fromJson(data, Major.class);

        logger.debug("major:"+major);
        boolean flag2=majorService.addMajor(major);
        PrintWriter writer=resp.getWriter();
        if(flag2){
            writer.print(1);
        }else {
            writer.print(0);
        }

    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
