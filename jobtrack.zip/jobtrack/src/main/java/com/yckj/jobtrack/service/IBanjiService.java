package com.yckj.jobtrack.service;

import com.yckj.jobtrack.domain.Banji;

import java.util.List;

public interface IBanjiService {
    boolean addBanji(Banji banji);
    List<Banji> findAll4();
    Banji findBanjiById(int id);
    boolean editBanji(Banji banji);
    boolean removeById(int id);
}
