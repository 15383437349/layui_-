package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.User;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import static org.junit.Assert.*;

public class UserMapperTest {

    @Test
    public void selectByUsernameAndPwd() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        User user = mapper.selectByUsernameAndPwd("huxiao", "123");
        System.out.println(user);
        MyBatisUtil.close(sqlSession);
    }
}