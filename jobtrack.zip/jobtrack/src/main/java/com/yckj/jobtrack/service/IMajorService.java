package com.yckj.jobtrack.service;


import com.yckj.jobtrack.domain.Major;

import java.util.List;

public interface IMajorService {
    boolean addMajor(Major major);
    List<Major> findAll3();

}
