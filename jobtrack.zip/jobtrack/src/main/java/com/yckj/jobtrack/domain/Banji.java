package com.yckj.jobtrack.domain;

public class Banji {
    private Integer id;
    private String cno;
    private String sdate;
    private  String edate;
    private String cnum;
    private String cpeo;
    private String ctel;
    private String fpeo;
    private String ftel;
    private String beizhu;



    @Override
    public String toString() {
        return "Banji{" +
                "id=" + id +
                ", cno='" + cno + '\'' +
                ", sdate='" + sdate + '\'' +
                ", edate='" + edate + '\'' +
                ", cnum='" + cnum + '\'' +
                ", cpeo='" + cpeo + '\'' +
                ", ctel='" + ctel + '\'' +
                ", fpeo='" + fpeo + '\'' +
                ", ftel='" + ftel + '\'' +
                ", beizhu=" + beizhu +
                '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCno() {
        return cno;
    }

    public void setCno(String cno) {
        this.cno = cno;
    }

    public String getSdate() {
        return sdate;
    }

    public void setSdate(String sdate) {
        this.sdate = sdate;
    }

    public String getEdate() {
        return edate;
    }

    public void setEdate(String edate) {
        this.edate = edate;
    }

    public String getCnum() {
        return cnum;
    }

    public void setCnum(String cnum) {
        this.cnum = cnum;
    }

    public String getCpeo() {
        return cpeo;
    }

    public void setCpeo(String cpeo) {
        this.cpeo = cpeo;
    }

    public String getCtel() {
        return ctel;
    }

    public void setCtel(String ctel) {
        this.ctel = ctel;
    }

    public String getFpeo() {
        return fpeo;
    }

    public void setFpeo(String fpeo) {
        this.fpeo = fpeo;
    }

    public String getFtel() {
        return ftel;
    }

    public void setFtel(String ftel) {
        this.ftel = ftel;
    }
    public String getBeizhu() {
        return beizhu;
    }

    public void setBeizhu(String beizhu) {
        this.beizhu = beizhu;
    }
}
