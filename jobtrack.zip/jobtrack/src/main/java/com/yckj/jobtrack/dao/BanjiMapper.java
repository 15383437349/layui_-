package com.yckj.jobtrack.dao;


import com.yckj.jobtrack.domain.Banji;

import java.util.List;

public interface BanjiMapper {
    int insert(Banji banji);
    List<Banji> selectAll4();
    /*通过ID查询合作的信息*/
    Banji selectById(int id);
    /*修改合作企业的信息*/
    int update(Banji ban);
    /*删除合作企业的信息*/
    int deleteById(int id);
}
