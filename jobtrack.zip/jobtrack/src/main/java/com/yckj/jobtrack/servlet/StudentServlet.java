package com.yckj.jobtrack.servlet;



import com.google.gson.Gson;
import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.domain.Student;
import com.yckj.jobtrack.service.IStudentService;

import com.yckj.jobtrack.service.impl.StudentServiceImpl;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(value="/StudentServlet")
public class StudentServlet  extends HttpServlet {
    private Logger logger=Logger.getLogger(this.getClass());
    private IStudentService studentService=new StudentServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //设置编码
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String method = req.getParameter("method");
        if("findAll5".equals(method)){
            this.findAll5(req,resp);
        }else if("addStudent".equals(method)){
            this.addStudent(req,resp);
        }else if("findStudentById".equals(method)){
            this.findStudentById(req,resp);
        }else if("editStudent".equals(method)){
            this.editStudent(req,resp);
        }else if("removeById".equals(method)){
            this.removeById(req,resp);
        }
        else{
            logger.debug("没有这个请求地址");
        }
    }



    private void findAll5(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        List<Student> students = studentService.findAll5();
        logger.debug(students);
        Map<String,Object> map= new LinkedHashMap<String,Object>();
        map.put("code",0);
        map.put("msg","");
        map.put("count",100);
        map.put("data",students);
        Gson gson=new Gson();
        String json = gson.toJson(map);
        logger.debug(json);
        PrintWriter writer = resp.getWriter();
        writer.print(json);
        writer.close();
    }
    private void addStudent(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String data = req.getParameter("data");
        logger.debug("data:"+data);
        Gson gson=new Gson();
        Student student=gson.fromJson(data,Student.class);
        logger.debug("student:"+student);
        boolean flag=studentService.addStudent(student);

        PrintWriter writer=resp.getWriter();
        if(flag){
            writer.print(1);
        }else {
            writer.print(0);
        }

    }
    private void findStudentById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        logger.debug("id="+id);

        if (id != null) {
            int i = Integer.parseInt(id);
            Student student = studentService.findStudentById(i);
            req.getSession().setAttribute("student",student);
            req.getRequestDispatcher(req.getContextPath()+"/page/student/editstudent.jsp").forward(req,resp);
        }else{
            logger.debug("id为空");
        }
    }
    private void editStudent(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String data = req.getParameter("data");

        Gson gson=new Gson();
        Student student = gson.fromJson(data,Student.class);

        boolean flag  = studentService.editStudent(student);
        PrintWriter writer=resp.getWriter();
        if(flag){
            writer.print(1);
        }else {
            writer.print(0);
        }
        writer.close();
    }

    private void removeById(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String id = req.getParameter("id");


        if (id != null) {
            int i = Integer.parseInt(id);

            boolean flag= studentService.removeById(i);

            PrintWriter writer = resp.getWriter();
            if(flag){
                writer.print(1);
            }else{
                writer.print(0);
            }
        }else{
            logger.debug("id为空");
        }
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       doGet(req, resp);
    }
}
