package com.yckj.jobtrack.service.impl;


import com.yckj.jobtrack.domain.Job;
import com.yckj.jobtrack.service.IJobService;
import org.junit.Test;

import java.util.List;



public class JobServiceImplTest {
    private IJobService jobService=new JobServiceImpl();
    @Test
    public void addJob() {
        Job job =new Job();
        job.setCname("西安羊肉泡馍1");
        job.setJname("食品检员");
        job.setMaincity("天津");
        job.setMnum(40);
        job.setSnum(20);
        job.setSpeople("王丽娜");
        job.setSpeopletel("15343456567");
        boolean flag1=jobService.addJob(job);
        if(flag1){
            System.out.println("添加成功");
        }
        else{
            System.out.println("添加失败");
        }

    }

    @Test
    public void findAll2() {
        List<Job> jobs = jobService.findAll2();
        System.out.println(jobs);
    }
}