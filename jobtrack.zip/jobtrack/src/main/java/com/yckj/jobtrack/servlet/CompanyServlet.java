package com.yckj.jobtrack.servlet;

import com.google.gson.Gson;
import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.service.ICompanyService;
import com.yckj.jobtrack.service.impl.CompanyServiceImpl;

import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(value="/CompanyServlet")
public class CompanyServlet  extends HttpServlet {
    private Logger logger=Logger.getLogger(this.getClass());
    private ICompanyService companyService=new CompanyServiceImpl();


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
       //设置编码
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String method = req.getParameter("method");
        if("findAll".equals(method)){
            this.findAll(req,resp);
        }else if("addCompany".equals(method)){
            this.addCompany(req,resp);
        }else if("findCompanyById".equals(method)){
            this.findCompanyById(req,resp);
        }else if("editCompany".equals(method)){
            this.editCompany(req,resp);
        }else if("removeById".equals(method)){
        this.removeById(req,resp);
    }
        else{
            logger.debug("没有这个请求地址");
        }

    }



    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }




/*查询合作类企业*/

    private void findAll(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        List<Company> companies = companyService.findAll();
        logger.debug(companies);
        Map<String,Object> map= new LinkedHashMap<String,Object>();
        map.put("code",0);
        map.put("msg","");
        map.put("count",100);
        map.put("data",companies);
        Gson gson=new Gson();
        String json = gson.toJson(map);
        logger.debug(json);
        PrintWriter writer = resp.getWriter();
        writer.print(json);
        writer.close();
    }

/*添加*/
    private void addCompany(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String data = req.getParameter("data");
        logger.debug("data:"+data);
        Gson gson=new Gson();
        Company company=gson.fromJson(data,Company.class);
        logger.debug("company:"+company);
        boolean flag=companyService.addCompany(company);

        PrintWriter writer=resp.getWriter();
        if(flag){
            writer.print(1);
        }else {
            writer.print(0);
        }

    }
/*通过id 查询*/

    private void findCompanyById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        logger.debug("id="+id);

        if (id != null) {
            int i = Integer.parseInt(id);
            Company company = companyService.findCompanyById(i);
            req.getSession().setAttribute("company",company);
            req.getRequestDispatcher(req.getContextPath()+"/page/company/editCompany.jsp").forward(req,resp);
        }else{
            logger.debug("id为空");
        }

    }
    /*修改*/
    private void editCompany(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String data = req.getParameter("data");

        Gson gson=new Gson();
        Company company = gson.fromJson(data,Company.class);

        boolean flag  = companyService.editCompany(company);
        PrintWriter writer=resp.getWriter();
        if(flag){
            writer.print(1);
        }else {
            writer.print(0);
        }
        writer.close();
    }
    /*删除*/
    private void removeById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");


        if (id != null) {
            int i = Integer.parseInt(id);

            boolean flag= companyService.removeById(i);

            PrintWriter writer = resp.getWriter();
            if(flag){
                writer.print(1);
            }else{
                writer.print(0);
            }
        }else{
            logger.debug("id为空");
        }
    }

}
