package com.yckj.jobtrack.service.impl;


import com.yckj.jobtrack.dao.JobMapper;

import com.yckj.jobtrack.domain.Job;

import com.yckj.jobtrack.service.IJobService;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class JobServiceImpl  implements IJobService {


    @Override
    public boolean addJob(Job job) {
        boolean flag = false;
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        JobMapper mapper = sqlSession.getMapper(JobMapper.class);
        int res = mapper.insert(job);
        if (res > 0) {
            sqlSession.commit();
            flag = true;
        } else {
            sqlSession.rollback();
        }
        return flag;

    }

    @Override
    public List<Job> findAll2() {
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        JobMapper mapper = sqlSession.getMapper(JobMapper.class);
        List<Job> jobs = mapper.selectAll2();
        return jobs;
    }

    @Override
    public Job findJobById(int id) {

        SqlSession sqlSession =MyBatisUtil.getSqlSession();
        JobMapper mapper=sqlSession.getMapper(JobMapper.class);
        Job job = mapper.selectById2(id);
        return job;
    }

}
