package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Job;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;
import org.junit.Test;

import java.util.List;

public class JobMapperTest {

    @Test
    public void insert() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        JobMapper mapper = sqlSession.getMapper(JobMapper.class);
        Job job =new Job();
        job.setCname("天津麻花");
        job.setJname("食品检员");
        job.setMaincity("天津");
        job.setMnum(40);
        job.setSnum(60);
        job.setSpeople("王丽娜");
        job.setSpeopletel("15343456567");
        int res=mapper.insert(job);
        if(res>0)
        {
            sqlSession.commit();
            System.out.println("添加成功");
        }
        else{
            sqlSession.rollback();
            System.out.println("添加失败");
        }
        MyBatisUtil.close(sqlSession);
    }

    @Test
    public void selectAll2() {
        SqlSession sqlSession= MyBatisUtil.getSqlSession();
        JobMapper mapper = sqlSession.getMapper(JobMapper.class);
        List<Job> jobs = mapper.selectAll2();
        System.out.println(jobs);
        sqlSession.close();
        MyBatisUtil.close(sqlSession);
    }
}