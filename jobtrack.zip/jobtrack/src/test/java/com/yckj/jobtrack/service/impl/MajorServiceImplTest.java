package com.yckj.jobtrack.service.impl;


import com.yckj.jobtrack.domain.Major;

import com.yckj.jobtrack.service.IMajorService;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class MajorServiceImplTest {
    private IMajorService majorService=new MajorServiceImpl();
    public void addMajor() {
        Major major=new Major();
       major.setMname("物联网工程");
       major.setCdate("2017-09");
       major.setBeizhu("新专业");
        boolean flag3=majorService.addMajor(major);

        if(flag3){
            System.out.println("添加成功");
        }
        else{
            System.out.println("添加失败");
        }

    }

    @Test
    public void findAll3() {
        List<Major> majors = majorService.findAll3();
        System.out.println(majors);
    }
}