package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Major;

import java.util.List;

public interface MajorMapper {
    /*查询所有合作的信息*/
    List<Major> selectAll3();

    int insert(Major major);
}
