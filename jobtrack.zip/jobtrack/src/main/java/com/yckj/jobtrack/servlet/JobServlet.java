package com.yckj.jobtrack.servlet;

import com.google.gson.Gson;

import com.yckj.jobtrack.domain.Company;
import com.yckj.jobtrack.domain.Job;

import com.yckj.jobtrack.service.IJobService;

import com.yckj.jobtrack.service.impl.JobServiceImpl;
import org.apache.log4j.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@WebServlet(value="/JobServlet")
public class JobServlet extends HttpServlet {
    private Logger logger=Logger.getLogger(this.getClass());
    private  IJobService jobService=new JobServiceImpl();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        //设置编码
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        String method = req.getParameter("method");
        if("findAll2".equals(method)){
            this.findAll2(req,resp);
        } else if("addJob".equals(method)){
            this.addJob(req,resp);
        }else{
            logger.debug("没有这个请求地址");
        }
    }



    private void findAll2(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        List<Job> jobs = jobService.findAll2();
        logger.debug(jobs);
        Map<String,Object> map= new LinkedHashMap<String,Object>();
        map.put("code",0);
        map.put("msg","");
        map.put("count",100);
        map.put("data",jobs);
        Gson gson=new Gson();
        String json = gson.toJson(map);
        logger.debug(json);
        PrintWriter writer = resp.getWriter();
        writer.print(json);
        writer.close();

    }

    private void addJob(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=utf-8");
        String data = req.getParameter("data");
        logger.debug("data:"+data);
        Gson gson=new Gson();
        Job job = gson.fromJson(data, Job.class);

        logger.debug("job:"+job);
        boolean flag1=jobService.addJob(job);
        PrintWriter writer=resp.getWriter();
        if(flag1){
            writer.print(1);
        }else {
            writer.print(0);
        }

    }

/*
    private void findJobById(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String id = req.getParameter("id");
        logger.debug("id="+id);

        if (id != null) {
            int i = Integer.parseInt(id);
            Job job = jobService.findJobById(i);
            req.getSession().setAttribute("job",job);
            req.getRequestDispatcher(req.getContextPath()+"/page/company/findJob.jsp").forward(req,resp);
        }else{
            logger.debug("id为空");
        }

    }
*/

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        doGet(req, resp);
    }
}
