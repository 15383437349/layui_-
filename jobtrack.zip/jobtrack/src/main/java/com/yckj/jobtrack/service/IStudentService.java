package com.yckj.jobtrack.service;


import com.yckj.jobtrack.domain.Student;

import java.util.List;

public interface IStudentService {
    /*
     * 添加学生，值为false表示添加失败
     * */
    boolean addStudent(Student student);
    List<Student> findAll5();


    Student findStudentById(int id);

    boolean editStudent(Student student);



    boolean removeById(int id);
}
