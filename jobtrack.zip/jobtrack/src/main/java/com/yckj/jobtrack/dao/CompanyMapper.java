package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Company;

import java.util.List;

public interface CompanyMapper {
    /*插入合作信息*/
    int insert(Company company);

    /*查询所有合作的信息*/
    List<Company> selectAll();
   /*通过ID查询合作的信息*/
    Company selectById( int id);
  /*修改合作企业的信息*/
    int update(Company company);
   /*删除合作企业的信息*/
    int deleteById(int id);

}
