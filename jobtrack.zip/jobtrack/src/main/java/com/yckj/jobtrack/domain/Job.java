package com.yckj.jobtrack.domain;

public class Job {
    private Integer  id;
 private  String cname;
 private  String  jname;
 private  String  zpeople;
 private  String   ftel;
 private  String   speople;
 private  String  speopletel;
 private  String   maincity;
 private  String   mainjob;
 private  Integer  mnum;
 private  Integer  snum;
 private  String  zplace;
 private  String  date1;



    @Override
    public String toString() {
        return "Job{" +
                "id='" + id +
                ",cname='" + cname + '\'' +
                ", jname='" + jname + '\'' +
                ", zpeople='" + zpeople + '\'' +
                ", ftel='" + ftel + '\'' +
                ", speople='" + speople + '\'' +
                ", speopletel='" + speopletel + '\'' +
                ", maincity='" + maincity + '\'' +
                ", mainjod='" + mainjob + '\'' +
                ", mnum=" + mnum +
                ", snum=" + snum +
                ", zplace='" + zplace + '\'' +
                ", date1='" + date1 + '\'' +
                '}';
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getJname() {
        return jname;
    }

    public void setJname(String jname) {
        this.jname = jname;
    }

    public String getZpeople() {
        return zpeople;
    }

    public void setZpeople(String zpeople) {
        this.zpeople = zpeople;
    }

    public String getFtel() {
        return ftel;
    }

    public void setFtel(String ftel) {
        this.ftel = ftel;
    }

    public String getSpeople() {
        return speople;
    }

    public void setSpeople(String speople) {
        this.speople = speople;
    }

    public String getSpeopletel() {
        return speopletel;
    }

    public void setSpeopletel(String speopletel) {
        this.speopletel = speopletel;
    }

    public String getMaincity() {
        return maincity;
    }

    public void setMaincity(String maincity) {
        this.maincity = maincity;
    }

    public String getMainjob() {
        return mainjob;
    }

    public void setMainjob(String mainjob) {
        this.mainjob = mainjob;
    }

    public Integer getMnum() {
        return mnum;
    }

    public void setMnum(Integer mnum) {
        this.mnum = mnum;
    }

    public Integer getSnum() {
        return snum;
    }

    public void setSnum(Integer snum) {
        this.snum = snum;
    }

    public String getZplace() {
        return zplace;
    }

    public void setZplace(String zplace) {
        this.zplace = zplace;
    }

    public String getDate1() {
        return date1;
    }

    public void setDate1(String date1) {
        this.date1 = date1;
    }
}
