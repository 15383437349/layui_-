package com.yckj.jobtrack.dao;

import com.yckj.jobtrack.domain.Banji;
import com.yckj.jobtrack.domain.Student;

import java.util.List;

public interface StudentMapper {
    int insert(Student student);
    List<Student> selectAll5();
    /*通过ID查询合作的信息*/
    Student selectById(int id);
    /*修改合作企业的信息*/
    int update(Student student);
    /*删除合作企业的信息*/
    int deleteById(int id);
}
