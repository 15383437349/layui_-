package com.yckj.jobtrack.service.impl;

import com.yckj.jobtrack.dao.UserMapper;
import com.yckj.jobtrack.domain.User;
import com.yckj.jobtrack.service.IUserService;
import com.yckj.jobtrack.util.MyBatisUtil;
import org.apache.ibatis.session.SqlSession;

public class UserServiceImpl implements IUserService {

    @Override
    public boolean login(User user) {
        boolean flag=false;
        SqlSession sqlSession = MyBatisUtil.getSqlSession();
        UserMapper mapper = sqlSession.getMapper(UserMapper.class);
        User user1 = mapper.selectByUsernameAndPwd(user.getUsername(), user.getPassword());
        if(user1 != null){
            flag=  true;

        }
        MyBatisUtil.close(sqlSession);
        return flag;
    }
}
